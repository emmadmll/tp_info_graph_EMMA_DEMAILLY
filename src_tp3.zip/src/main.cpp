#include "viewer.h"
#include "triangle.h"
//#include "pyramid.h"
#include "cylinder.h"
#include "node.h"
#include "shader.h"
#include <string>

#ifndef SHADER_DIR
#error "SHADER_DIR not defined"
#endif

int main()
{
    // create window, add shaders & scene objects, then run rendering loop
    Viewer viewer;

    // get shader directory
    std::string shader_dir = SHADER_DIR;

    Shader *color_shader = new Shader(shader_dir + "node.vert", shader_dir + "node.frag");

    glm::mat4 human_mat = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -5.0f))
        * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 1.0f, 1.0f))
        * glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    
    // crée le premier noeud qui va tout contenir
    Node* human = new Node(human_mat);
    
    // TODO create the human skeleton
    
    //creation des sous noeuds
    //on définit une matrice de rotation pour que le cylindre s'affiche face à la caméra
    glm::mat4 rotation_buste = glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 translation_buste = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
    //on crée un noeud buste
    Node* buste = new Node(rotation_buste * translation_buste * glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 4.0f, 0.5f)));
    
    //on donne une forme au buste, on dit que c'est un cylindre
    Shape* buste_forme = new Cylinder(color_shader, 1.0f, 0.5f, 100);
    
    //on ajoute au noeud buste, la forme du buste (le cylindre)
    buste->add(buste_forme);
    
    //on ajoute au noeud human le noeud buste
    human->add(buste);
    
    
    //On fait la même chose pour faire le demi haut bras gauche. Pas besoin de faire de rotation car elle se fait déjà (héritage du noeud buste)
    glm::mat4 translation_upperbrasG = glm::translate(glm::mat4(1.0f), glm::vec3(-0.75f, 0.0f, -0.25f));
    Node* upperbrasG = new Node(translation_upperbrasG * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.5f, 0.5f)));
    Shape* upperbrasG_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    upperbrasG->add(upperbrasG_forme);
    buste->add(upperbrasG);
    
    //dans la transaltion, comme on a fait une rotation avant alors le repère a tourné, il faut aller dans les négatifs pour monter
    
    
    //Création du demi bras haut droit
    glm::mat4 translation_upperbrasD = glm::translate(glm::mat4(1.0f), glm::vec3(0.75, 0.0f, -0.25f));
    Node* upperbrasD = new Node(translation_upperbrasD * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.5f, 0.5f)));
    Shape* upperbrasD_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    upperbrasD->add(upperbrasD_forme);
    buste->add(upperbrasD);
    
    
    //création de l'avant bras gauche. Pas besoin de translation car elle est déjà faite par le node parent.
    // pour le glm::scale on met tout à 1.0 car il a la même taille que sont node parent upperbrasG
    glm::mat4 translation_avantBrasG = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    Node* avantBrasG = new Node (translation_avantBrasG * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 1.0f, 1.0f)));
    Shape* avantBrasG_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    avantBrasG->add(avantBrasG_forme);
    upperbrasG->add(avantBrasG);
    
    
    //création de l'avant bras droit. pas besoin de scale dans Node*avantBrasD car elle garde la même taille que le node parent
    glm::mat4 translation_avantBrasD = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    Node* avantBrasD = new Node (translation_avantBrasD);
    Shape* avantBrasD_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    avantBrasD->add(avantBrasD_forme);
    upperbrasD->add(avantBrasD);
    
    
    //création de la demi jambe gauche haute
    glm::mat4 translation_upperLegG = glm::translate(glm::mat4(1.0f), glm::vec3(-0.25f, 0.0f, 0.75f));
    Node* upperLegG = new Node (translation_upperLegG * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.5f, 0.5f)));
    Shape* upperLegG_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    upperLegG->add(upperLegG_forme);
    buste->add(upperLegG);
    
    
    //création de la demi jambe droite haute
    glm::mat4 translation_upperLegD = glm::translate(glm::mat4(1.0f), glm::vec3(0.25f, 0.0f, 0.75f));
    Node* upperLegD = new Node (translation_upperLegD * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.5, 0.5f)));
    Shape* upperLegD_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    upperLegD->add(upperLegD_forme);
    buste->add(upperLegD);
    
    
    //création de la demi jambe gauche basse. pas besoin de scale car même taille que demi jambe haute
    glm::mat4 translation_lowerLegG = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    Node* lowerLegG = new Node(translation_lowerLegG);
    Shape* lowerLegG_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    lowerLegG->add(lowerLegG_forme);
    upperLegG->add(lowerLegG);
    
    
    //création de la demi jambe droite basse. pas besoin de scale car même taille que son node parent
    glm::mat4 translation_lowerLegD = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    Node* lowerLegD = new Node(translation_lowerLegD);
    Shape* lowerLegD_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    lowerLegD->add(lowerLegD_forme);
    upperLegD->add(lowerLegD);
    
    
    //création de la tête
    glm::mat4 translation_tete = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -1.0f));
    Node* tete = new Node(translation_tete * glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.5f, 0.5f)));
    Shape* tete_forme = new Cylinder(color_shader, 1.0f, 0.25f, 100);
    tete->add(tete_forme);
    buste->add(tete); 
    
    
//  ajout animation

    viewer.update_callback = [&](){
        // définition du temps
        float t = (float)glfwGetTime();
        
        float vitesse = 5.0f;   // vitesse de mouvement du bras
        float lift = 110.0f;    // position de base du bras
        float range = 30.0f;    // amplitude du mouvement
        
        float wave = range * sin(t * vitesse);  // oscillations
        
        float angleG = glm::radians(lift + wave);    // angle final. On oscille de + ou - 30° autour de la position de base
        
        //définition de la rotation, translation et scale pour la transformation
        glm::mat4 translation = glm::translate(glm::mat4(1.0f), glm::vec3(-0.80, 0.0f, -0.70f));
        glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), angleG, glm::vec3(0.0f, -1.0f, 0.0f));
        glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(0.65f, 0.75f, 0.75f));
        
        // on crée la transformation à l'aide de la translation, rotation et scale qu'on a défini avant
        glm::mat4 upperBrasG_transformation = scale * translation * rotation ;
        
        
        //on refait pareil pour le bras droit :
        float angleD = glm::radians(-lift - wave);
        
        glm::mat4 translationD = glm::translate(glm::mat4(1.0f), glm::vec3(0.80, 0.0f, -0.70f));
        glm::mat4 rotationD = glm::rotate(glm::mat4(1.0f), angleD, glm::vec3(0.0f, -1.0f, 0.0f));
        glm::mat4 scaleD = glm::scale(glm::mat4(1.0f), glm::vec3(0.65f, 0.75f, 0.75f));
        glm::mat4 upperBrasD_transformation = scaleD * translationD * rotationD ;
        
        // on applique la transformation, les node enfants vont faire la même chose
        upperbrasG->set_transform(upperBrasG_transformation);
        upperbrasD->set_transform(upperBrasD_transformation);
    };

    viewer.scene_root->add(human);

    viewer.run();
}
