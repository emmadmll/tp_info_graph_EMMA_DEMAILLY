#include "pyramide.h"

#include <iostream>
#include <glm/vec3.hpp> // glm::vec3
#include <glm/vec4.hpp> // glm::vec4
#include <glm/mat4x4.hpp> // glm::mat4
#include <glm/gtc/matrix_transform.hpp> // glm::translate, glm::rotate, glm::scale, glm::perspective
#include <glm/gtc/type_ptr.hpp>
#include <GLFW/glfw3.h> // pour inclure le temps

Pyramide::Pyramide(Shader *shader_program) : shader_program_(shader_program->get_id()) {
    
    //On définit les coordonnées des points de la pyramide
    GLfloat vertex_buffer_data[] = {
        -0.5f, -0.5f, -0.5f,  // équivalent point 0
        0.5f, -0.5f, -0.5f,  // équivalent point 1
        0.5f, -0.5f, 0.5f,  // équivalent point 2
        -0.5f, -0.5f, 0.5f, // équivalent point 3
        0.0f, 0.5f, 0.0f    // équivalent point 4
    };
    
    //On définit les arrêtes
    GLuint indices[] = {
        // pour la base
        0, 1, 2,
        2, 3, 0,
        // pour les côtés de la pyramide
        0, 4, 3,
        3, 4, 2,
        2, 4, 1,
        1, 4, 0
    };
    
    //On crée le VAO qui contient les coordonnées des sommets et les arretes à relier
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // On crée les buffers
    glGenBuffers(2, &buffers[0]);

    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);   //GL_ARRAY_BUFFER pour faire dire qu'on s'interesse au buffer des coordonnées
    // copie les données des coordonnées des points sur le GPU pour pouvoir ensuite les utiliser et dessiner la pyramide
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertex_buffer_data), vertex_buffer_data, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL); //indique que les points se lisent par paquet de 3 composantes
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, buffers[1]);   //GL_ELEMENT_ARRAY_BUFFER pour les indices
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); //pareil que avant mais pour les indices
    
}

// Destructeur
Pyramide::~Pyramide() {
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &buffers[0]);
}

void Pyramide::draw() {
    
    //active le shader et permet de définir les fonctions nécessaires à l'affichage de la pyramide
    glUseProgram( this->shader_program_ );
    glBindVertexArray( VAO );
 
    //Translation
    glm::mat4 translation = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -3.0f));

    //Rotation en fonction du temps GetTime et autour de l'axe y
    //on commence par définir angle en multipliant le temps par une vitesse angulaire
    float angle = glfwGetTime() * glm::radians(50.0f);
    
    glm::mat4 rotation = glm::rotate(glm::mat4(1.0f),
                                     angle,
                                     glm::vec3(0.0f, 1.0f, 0.0f));

    //Scale, on garde la taille normale
    glm::mat4 scale = glm::scale(glm::mat4(1.0f),
                                 glm::vec3(1.0f, 1.0f, 1.0f));
    
    //projection, permet d'ajouter de la perspective
    glm::mat4 projection = glm::perspective(
        glm::radians(45.0f),
        4.0f/3.0f,
        0.1f,
        100.0f);

    //matrice finale
    glm::mat4 view = translation * rotation * scale;

    glUseProgram( shader_program_) ; //this->shader_program_ );
    //donne l'emplacement de l'uniform dans le shader
    GLint id = glGetUniformLocation(this->shader_program_, "view");
    GLint projID = glGetUniformLocation(shader_program_, "projection");

    //envoi des matrices au shader pour qu'il sache comment faire les transformations
    glUniformMatrix4fv(id, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projID, 1, GL_FALSE, glm::value_ptr(projection));

    glBindVertexArray( VAO );
    
    /* draw points 0-3 from the currently bound VAO with current in-use shader */
    glDrawElements( GL_TRIANGLES, 18, GL_UNSIGNED_INT, 0 );
}

void Pyramide::key_handler(int key) {
    return;
}

